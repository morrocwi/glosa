"""tests/test_kernel.py

tier: finite_diagnostic (tests executed: `python3 -m unittest discover -s tests -v`, run from
the glosa repo root -- see the command's actual output recorded in the task handoff / PR
description; this file IS the executed command referenced by kernel/glosa_kernel.py's own header).

Covers every function in kernel/glosa_kernel.py against:
  - the 20 valid examples in schema/examples/*.example.json (the ones relevant to each
    validate_* function),
  - all six deliberate-FAIL fixtures in schema/examples/fail/*.json (each must be REJECTED, and
    for the five with a clearly-named §3.3 rule, this file also asserts the specific rule fires
    by checking the rejection reason mentions that rule),
  - the 11 numbered kernel gate rules of FOUNDATION_v0.5.md §3.3, individually, via small
    hand-built payloads that isolate exactly one rule at a time (mutated copies of the valid
    claim_card example, mirroring the fail-fixture convention documented in schema/README.md),
  - route_genre's 9-step procedure, one case per terminal genre,
  - independence_ceiling, defeater_route (Readout Condition Proposition 3), silent_lift_check,
    mc01_check, lit_gate, compute_disclaimers, and self_test.

Runnable with either `pytest` or stdlib `python3 -m unittest discover -s tests`.
"""

import copy
import json
import sys
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "kernel"))

import glosa_kernel as k  # noqa: E402

SCHEMA_DIR = REPO_ROOT / "schema"
EXAMPLES_DIR = SCHEMA_DIR / "examples"
FAIL_DIR = EXAMPLES_DIR / "fail"


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_example(name):
    return load(EXAMPLES_DIR / name)


def load_fail(name):
    instance = load(FAIL_DIR / name)
    instance.pop("_fail_reason", None)
    return instance


class ValidClaimCardTest(unittest.TestCase):
    def test_valid_claim_card_passes(self):
        card = load_example("claim_card.example.json")
        # rule28 (INFLATED-BEARING, K-C3) needs the resolvable citation set to confirm the
        # card's own evidence_relations[0].citation_ref actually resolves; without it,
        # validate_claim_card still passes (ok=True) but with a "not fully checked" warning
        # (see test_valid_claim_card_passes_with_limits_when_citation_cards_omitted below) --
        # PASS (no warnings at all) requires supplying the real citation set.
        citation_cards = [load_example("citation_card.example.json")]
        res = k.validate_claim_card(card, citation_cards=citation_cards)
        self.assertTrue(res["ok"], res["errors"])
        self.assertEqual(res["verdict"], "PASS")
        self.assertEqual(res["tier"], "finite_diagnostic")

    def test_valid_claim_card_passes_with_limits_when_citation_cards_omitted(self):
        """rule28 (INFLATED-BEARING) cannot confirm citation_ref resolution without
        citation_cards; validate_claim_card still returns ok=True (never a fabricated hard
        fail), but surfaces the gap as a warning -- PASS_WITH_LIMITS, not a silent PASS."""
        card = load_example("claim_card.example.json")
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertEqual(res["verdict"], "PASS_WITH_LIMITS")
        self.assertTrue(any("rule28" in w for w in res["warnings"]), res["warnings"])

    def test_result_shape(self):
        card = load_example("claim_card.example.json")
        res = k.validate_claim_card(card)
        self.assertEqual(set(res.keys()), {"ok", "verdict", "errors", "warnings", "tier"})

    def test_non_object_input_fails(self):
        res = k.validate_claim_card("not a dict")
        self.assertFalse(res["ok"])
        self.assertEqual(res["verdict"], "FAIL")


class FailFixtureTest(unittest.TestCase):
    """Every schema/examples/fail/*.json fixture must be rejected by validate_claim_card, and the
    rejection must mention the specific rule its own _fail_reason names."""

    def test_fail_same_model_review_rule1(self):
        card = load_fail("fail_same_model_review.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("independent_check" in e or "Kernel rule 1" in e or "PASSED" in e for e in res["errors"]), res["errors"])

    def test_fail_no_independent_check_rule9(self):
        card = load_fail("fail_no_independent_check.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    def test_fail_missing_disclaimer(self):
        card = load_fail("fail_missing_disclaimer.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    def test_fail_th_coqc_no_witness_rule2(self):
        card = load_fail("fail_th_coqc_no_witness.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    def test_fail_stub_public_rule10(self):
        card = load_fail("fail_stub_public.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    def test_fail_k2_without_i5_rule4(self):
        card = load_fail("fail_k2_without_i5.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    def test_fail_ai_signs_claim_rule15(self):
        card = load_fail("fail_ai_signs_claim.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(
            any("rule15" in e for e in res["errors"]) or any("inference_to_claim" in e for e in res["errors"]),
            res["errors"],
        )

    def test_all_fail_fixtures_rejected_by_self_test(self):
        res = k.self_test()
        self.assertTrue(res["ok"], res["errors"])


class KernelRuleIsolationTest(unittest.TestCase):
    """Isolate each of §3.3's 11 numbered rules with a minimal mutation of the valid example,
    mirroring schema/README.md's own fail-fixture convention (diff against claim_card.example.json
    shows exactly what was changed)."""

    def setUp(self):
        self.card = load_example("claim_card.example.json")

    def test_rule1_mc02_passed_requires_not_i0_i1(self):
        card = copy.deepcopy(self.card)
        card["independent_check"] = {
            "status": "PASSED", "maker_id": "founder", "checker_id": "founder",
            "approver_id": "founder", "independence_class": "I1", "mc_level": "L1",
            "date": "2026-09-04", "expires_at": None,
        }
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

        card["independent_check"]["independence_class"] = "I3"
        card["independent_check"]["checker_id"] = "route R2"
        res2 = k.validate_claim_card(card)
        # rule 1 itself should no longer fire (other rules may still comment on k_state etc.,
        # so we only assert the PASSED/I0-I1 combination is gone from the error set)
        self.assertFalse(any("independence_class" in e and "PASSED" in e for e in res2["errors"]))

    def test_rule2_th_coqc_requires_i4_or_i5(self):
        card = copy.deepcopy(self.card)
        card["tier"] = "Th_coqc"
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I3"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I4"
        res2 = k.validate_claim_card(card)
        self.assertTrue(res2["ok"], res2["errors"])

    def test_rule3_finite_diagnostic_requires_i4_or_i5(self):
        card = copy.deepcopy(self.card)
        card["tier"] = "finite_diagnostic"
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I3"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I5"
        res2 = k.validate_claim_card(card)
        self.assertTrue(res2["ok"], res2["errors"])

    def test_rule4_k2_k3_require_i5(self):
        card = copy.deepcopy(self.card)
        card["k_state"] = "K2"
        card["provenance_dag"]["status"] = "run"
        card["silent_lift_check"]["status"] = "run"
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I4"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I5"
        res2 = k.validate_claim_card(card)
        self.assertTrue(res2["ok"], res2["errors"])

    def test_rule5_mc01_pairwise_distinct_once_past_pending_review(self):
        card = copy.deepcopy(self.card)
        card["status"] = "Approved-for-Test"
        card["k_state"] = None
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I3"
        card["independent_check"] = {
            "status": "PASSED", "maker_id": "founder", "checker_id": "founder",
            "approver_id": "someone-else", "independence_class": "I3", "mc_level": "L3",
            "date": "2026-09-04", "expires_at": None,
        }
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("MC-01" in e or "mc01" in e for e in res["errors"]), res["errors"])

        card["independent_check"]["checker_id"] = "an independent checker"
        res2 = k.validate_claim_card(card)
        self.assertFalse(any("mc01" in e.lower() for e in res2["errors"]), res2["errors"])

    def test_rule5_does_not_fire_while_still_draft(self):
        card = copy.deepcopy(self.card)
        card["independent_check"] = {
            "status": "NONE", "maker_id": "founder", "checker_id": "founder",
            "approver_id": "founder", "independence_class": "I1", "mc_level": "L1",
            "date": "2026-09-04", "expires_at": None,
        }
        self.assertEqual(card["status"], "Draft")
        res = k.validate_claim_card(card)
        self.assertFalse(any("mc01" in e.lower() for e in res["errors"]), res["errors"])

    def test_rule6_claim_scope_may_not_exceed_evidence_scope(self):
        card = copy.deepcopy(self.card)
        card["scope"]["claim_scope"] = "true for all cats in general"
        card["scope"]["evidence_scope"] = "one household, one cat, 14 days"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule6" in e for e in res["errors"]), res["errors"])

    def test_rule6_population_claim_over_single_subject_evidence(self):
        card = copy.deepcopy(self.card)
        card["scope"]["generalization_claimed"] = "population_claim"
        card["scope"]["evidence_scope"] = "n=1 cat"
        card["scope"]["claim_scope"] = "n=1 cat"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule6" in e for e in res["errors"]), res["errors"])

    def test_rule6_matched_scope_passes(self):
        card = copy.deepcopy(self.card)
        card["scope"]["claim_scope"] = "one household, one cat, 14 days"
        card["scope"]["evidence_scope"] = "one household, one cat, 14 days"
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])

    def test_rule7_silent_lift_flags_block_status(self):
        card = copy.deepcopy(self.card)
        card["silent_lift_check"]["flags"] = ["unexplained-dependency-X"]
        card["status"] = "Approved-for-Test"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    def test_rule8_external_validation_proposed_hard_fail(self):
        card = copy.deepcopy(self.card)
        card["statement"]["text"] = card["statement"]["text"] + " We should seek external validation to confirm this."
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("EXTERNAL_VALIDATION_PROPOSED" in e for e in res["errors"]), res["errors"])

    def test_rule8_clean_text_passes(self):
        card = copy.deepcopy(self.card)
        res = k.validate_claim_card(card)
        self.assertFalse(any("EXTERNAL_VALIDATION_PROPOSED" in e for e in res["errors"]), res["errors"])

    def test_rule9_k1_requires_i3_plus_or_bounded_exception(self):
        card = copy.deepcopy(self.card)
        card["k_state"] = "K1"
        card["provenance_dag"]["status"] = "run"
        card["silent_lift_check"]["status"] = "run"
        # only I1 evidence, no exception markers -> fail
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

        # add an I3 route -> passes
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I3"
        res2 = k.validate_claim_card(card)
        self.assertTrue(res2["ok"], res2["errors"])

    def test_rule9_bounded_exception_within_90_days_passes(self):
        card = copy.deepcopy(self.card)
        card["k_state"] = "K1"
        card["provenance_dag"]["status"] = "run"
        card["silent_lift_check"]["status"] = "run"
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I2"
        card["five_questions"]["tested"]["evidence_relations"].append({
            "evidence_id": "ev-cat-004", "bearing": "SUPPORTS", "independence_class": "I4",
            "citation_ref": "cite-cat-obs-001", "strength": "mechanical", "review_mode": "MECHANICAL_CHECK",
            "route_id": None, "asserted_by": "validator", "date": "2026-09-05", "notes": "",
        })
        card["disclaimers_emitted"].append({"id": "D-SAME-VENDOR"})
        card["independent_check"]["expires_at"] = "2026-11-01"  # date is 2026-09-04, 58 days later
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])

    def test_rule9_bounded_exception_beyond_90_days_fails(self):
        card = copy.deepcopy(self.card)
        card["k_state"] = "K1"
        card["provenance_dag"]["status"] = "run"
        card["silent_lift_check"]["status"] = "run"
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I2"
        card["five_questions"]["tested"]["evidence_relations"].append({
            "evidence_id": "ev-cat-004", "bearing": "SUPPORTS", "independence_class": "I4",
            "citation_ref": "cite-cat-obs-001", "strength": "mechanical", "review_mode": "MECHANICAL_CHECK",
            "route_id": None, "asserted_by": "validator", "date": "2026-09-05", "notes": "",
        })
        card["disclaimers_emitted"].append({"id": "D-SAME-VENDOR"})
        card["independent_check"]["date"] = "2026-09-04"
        card["independent_check"]["expires_at"] = "2027-01-15"  # far more than 90 days later
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("90-day" in e for e in res["errors"]), res["errors"])

    def test_rule10_stub_cannot_advance_past_draft(self):
        card = load_fail("fail_stub_public.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

        card["status"] = "Draft"
        res2 = k.validate_claim_card(card)
        self.assertTrue(res2["ok"], res2["errors"])

    def test_rule11_provenance_and_silent_lift_must_be_run_before_k1(self):
        card = copy.deepcopy(self.card)
        card["k_state"] = "K1"
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I3"
        card["provenance_dag"]["status"] = "not_run"
        card["silent_lift_check"]["status"] = "run"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

        card["provenance_dag"]["status"] = "run"
        res2 = k.validate_claim_card(card)
        self.assertTrue(res2["ok"], res2["errors"])

    def test_rule15_ai_signs_claim_fails(self):
        """Kernel rule 15 (FOUNDATION_v0.5.md §2.1b, founder instruction 2026-09-04,
        BBL-2026-09-04-083/084): responsibility.inference_to_claim must be 'human'."""
        card = copy.deepcopy(self.card)
        card["responsibility"]["inference_to_claim"] = "ai"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(
            any("rule15" in e and "human" in e for e in res["errors"]), res["errors"]
        )

    def test_rule15_ai_owns_question_fails(self):
        """FOUNDATION §2.1c (BBL-2026-09-04-086): problem/question/hypothesis stay human."""
        card = copy.deepcopy(self.card)
        card["responsibility"] = {"data_to_inference": "joint", "inference_to_claim": "human",
                                  "ownership": {"problem": "human", "question": "ai", "hypothesis_selection": "human"}}
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule15" in e and "ownership" in e for e in res["errors"]), res["errors"])

    def test_rule15_human_signs_claim_passes(self):
        card = copy.deepcopy(self.card)
        card["responsibility"]["inference_to_claim"] = "human"
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertFalse(any(w.startswith("rule15w") for w in res["warnings"]), res["warnings"])

    def test_rule15w_warns_when_responsibility_absent(self):
        card = copy.deepcopy(self.card)
        card.pop("responsibility", None)
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertTrue(any(w.startswith("rule15w") for w in res["warnings"]), res["warnings"])

    def test_rule16w_warns_when_empirical_extension_absent(self):
        card = copy.deepcopy(self.card)
        self.assertEqual(card["claim_type"], "EMPIRICAL")
        card.pop("empirical_extension", None)
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertTrue(any(w.startswith("rule16w") for w in res["warnings"]), res["warnings"])

    def test_rule16w_silent_when_empirical_extension_present(self):
        card = copy.deepcopy(self.card)
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertFalse(any(w.startswith("rule16w") for w in res["warnings"]), res["warnings"])

    def test_rule16w_silent_for_non_empirical_claim_type(self):
        card = copy.deepcopy(self.card)
        card["claim_type"] = "FORMAL"
        card.pop("empirical_extension", None)
        res = k.validate_claim_card(card)
        self.assertFalse(any(w.startswith("rule16w") for w in res["warnings"]), res["warnings"])


class ReviewReportTest(unittest.TestCase):
    def test_valid_review_report_passes(self):
        report = load_example("review_report.example.json")
        res = k.validate_review_report(report)
        self.assertTrue(res["ok"], res["errors"])

    def test_missing_verdict_tier_fails_bounded_judge_law(self):
        report = load_example("review_report.example.json")
        del report["verdict_tier"]
        res = k.validate_review_report(report)
        self.assertFalse(res["ok"])

    def test_reviewer_same_as_maker_fails(self):
        report = load_example("review_report.example.json")
        res = k.validate_review_report(report, maker_id=report["reviewer_identity"])
        self.assertFalse(res["ok"])

    def test_reviewer_same_as_approver_fails(self):
        report = load_example("review_report.example.json")
        res = k.validate_review_report(report, approver_id=report["reviewer_identity"])
        self.assertFalse(res["ok"])


class CitationCardTest(unittest.TestCase):
    def test_rule17_citation_from_memory_fails(self):
        """Founder ruling 2026-09-04 (BBL-2026-09-04-100): a fetched citation without the link it
        was read from + page + line + verbatim passage cannot stand above CANDIDATE."""
        c = load_example("citation_card.example.json")
        c["fetch_status"] = "FETCHED"; c["status"] = "VERIFIED"; c.pop("fetched_from_url", None)
        res = k.validate_citation_card(c)
        self.assertFalse(res["ok"]); self.assertTrue(any("rule17(" in e for e in res["errors"]), res["errors"])
        c["status"] = "CANDIDATE"
        res = k.validate_citation_card(c)
        self.assertTrue(res["ok"], res["errors"]); self.assertTrue(any("rule17w" in w for w in res["warnings"]))

    def test_valid_citation_card_passes(self):
        citation = load_example("citation_card.example.json")
        res = k.validate_citation_card(citation)
        self.assertTrue(res["ok"], res["errors"])

    def test_verified_requires_both_booleans(self):
        citation = load_example("citation_card.example.json")
        citation["metadata_verified"] = False
        res = k.validate_citation_card(citation)
        self.assertFalse(res["ok"])

    def test_scrammed_requires_xenon_ledger_ref(self):
        citation = load_example("citation_card.example.json")
        citation["status"] = "SCRAMMED"
        citation["xenon_ledger_ref"] = None
        res = k.validate_citation_card(citation)
        self.assertFalse(res["ok"])

        citation["xenon_ledger_ref"] = "cases/worked-example-cat/XENON_LEDGER.md#row-1"
        res2 = k.validate_citation_card(citation)
        self.assertTrue(res2["ok"], res2["errors"])


class ReleaseManifestTest(unittest.TestCase):
    def test_valid_release_manifest_passes(self):
        manifest = load_example("release_manifest.example.json")
        res = k.validate_release_manifest(manifest)
        self.assertTrue(res["ok"], res["errors"])

    def test_blackbox_note_precondition_on_approved_for_live(self):
        manifest = load_example("release_manifest.example.json")
        manifest["status"] = "Approved-for-Live"
        manifest["blackbox_note_appendix_present"] = False
        res = k.validate_release_manifest(manifest)
        self.assertFalse(res["ok"])

    def test_pub_adversarial_review_fail_dimension_blocks_pass_verdict(self):
        manifest = load_example("release_manifest.example.json")
        manifest["adversarial_review"]["r1_leak_scan"]["result"] = "FAIL"
        manifest["gate_verdict"] = "PASS"
        res = k.validate_release_manifest(manifest)
        self.assertFalse(res["ok"])


class BlackboxNoteTest(unittest.TestCase):
    def test_valid_blackbox_note_passes(self):
        note = load_example("blackbox_note.example.json")
        res = k.validate_blackbox_note(note)
        self.assertTrue(res["ok"], res["errors"])

    def test_dangling_cooking_input_line_fails(self):
        note = load_example("blackbox_note.example.json")
        note["cooking"][0]["input_lines"] = [999]
        res = k.validate_blackbox_note(note)
        self.assertFalse(res["ok"])

    def test_public_line_without_privacy_scan_done_fails(self):
        note = load_example("blackbox_note.example.json")
        note["privacy_scan"] = "pending"
        res = k.validate_blackbox_note(note)
        self.assertFalse(res["ok"])


class ComputeDisclaimersTest(unittest.TestCase):
    def test_always_on_ids_present(self):
        card = load_example("claim_card.example.json")
        ids = {d["id"] for d in k.compute_disclaimers(card)}
        for always_id in ("D-STANDPOINT", "D-NONEXPERT", "D-NONCLAIM", "D-AUTHORSHIP", "D-REVISION-LIVE", "D-NO-EPISTEMIC-VETO", "D-BLACKBOX-NOTE"):
            self.assertIn(always_id, ids)

    def test_d_independence_fires_on_weak_evidence(self):
        card = load_example("claim_card.example.json")
        self.assertEqual(card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"], "I1")
        ids = {d["id"] for d in k.compute_disclaimers(card)}
        self.assertIn("D-INDEPENDENCE", ids)

    def test_d_independence_absent_once_i3_reached(self):
        card = load_example("claim_card.example.json")
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I3"
        ids = {d["id"] for d in k.compute_disclaimers(card)}
        self.assertNotIn("D-INDEPENDENCE", ids)

    def test_d_scope_fires_when_generalization_claimed(self):
        card = load_example("claim_card.example.json")
        card["scope"]["generalization_claimed"] = "pattern_candidate"
        ids = {d["id"] for d in k.compute_disclaimers(card)}
        self.assertIn("D-SCOPE", ids)

    def test_d_derived_patterns_fires_on_private_repo_reference(self):
        card = load_example("claim_card.example.json")
        card["ledger"]["borrowed"] = ["pattern re-derived from privaterepo-x (private, patterns only)"]
        # private source names are NOT shipped in the public kernel (git-ignored registry file /
        # env var) -- inject one for the test so it is environment-independent (CI has none).
        saved = list(k._PRIVATE_REPO_NAMES)
        k._PRIVATE_REPO_NAMES[:] = ["privaterepo-x"]
        try:
            ids = {d["id"] for d in k.compute_disclaimers(card)}
        finally:
            k._PRIVATE_REPO_NAMES[:] = saved
        self.assertIn("D-EXTERNAL-INPUT", ids)
        self.assertIn("D-DERIVED-PATTERNS", ids)

    def test_uses_catalogue_file_when_present(self):
        self.assertTrue(k.DISCLAIMER_CATALOGUE_PATH.is_file(), "methodology/data/disclaimer_catalogue.json should exist per Task B1")
        rows, source = k._load_disclaimer_catalogue()
        self.assertEqual(source, str(k.DISCLAIMER_CATALOGUE_PATH))
        self.assertGreater(len(rows), 20)

    def test_falls_back_to_embedded_table_when_file_missing(self):
        original = k.DISCLAIMER_CATALOGUE_PATH
        try:
            k.DISCLAIMER_CATALOGUE_PATH = REPO_ROOT / "does-not-exist.json"
            rows, source = k._load_disclaimer_catalogue()
            self.assertEqual(rows, k._EMBEDDED_MINIMAL_DISCLAIMER_TABLE)
            self.assertIn("EMBEDDED_MINIMAL_DISCLAIMER_TABLE", source)
        finally:
            k.DISCLAIMER_CATALOGUE_PATH = original


class RouteGenreTest(unittest.TestCase):
    def test_case_study_from_worked_example(self):
        card = load_example("claim_card.example.json")
        result = k.route_genre(card)
        self.assertEqual(result["genre"], "case_study")
        self.assertEqual(result["venue_track"], card.get("venue_track"))
        self.assertEqual(result["companion_of"], card.get("companion_of"))
        self.assertTrue(result["reasons"])

    def test_empirical_qual_practice_when_not_bounded(self):
        card = load_example("claim_card.example.json")
        result = k.route_genre(card, context={"bounded_case": False})
        self.assertEqual(result["genre"], "empirical_qual_practice")

    def test_formal_proof_when_exact_functional_and_no_mechanical_evidence(self):
        card = load_example("claim_card.example.json")
        card["lens_translation"]["formal_applicability"] = "exact_functional"
        result = k.route_genre(card)
        self.assertEqual(result["genre"], "formal_proof")

    def test_systematic_review_from_context(self):
        card = load_example("claim_card.example.json")
        result = k.route_genre(card, context={"has_search_log": True})
        self.assertEqual(result["genre"], "systematic_review")

    def test_archival_from_seen_access_model(self):
        card = load_example("claim_card.example.json")
        card["five_questions"]["seen"]["access_model"] = "archival record in a household document register"
        card["five_questions"]["seen"]["retrievable_original"] = True
        result = k.route_genre(card)
        self.assertEqual(result["genre"], "archival")

    def test_position_reply_from_lineage(self):
        card = load_example("claim_card.example.json")
        card["lineage"]["derives_from"] = ["GLOSA-CC-20260101-0001"]
        result = k.route_genre(card)
        self.assertEqual(result["genre"], "position_reply")

    def test_design_science_from_decision_policy_augmentation(self):
        card = load_example("claim_card.example.json")
        card["claim_type"] = "DECISION"
        card["five_questions"]["assumed"].append({
            "id": "A9", "type": "decision_policy_augmentation",
            "description": "built a scheduling protocol", "identification_level": "A2",
            "contaminated_concept_hit": None,
        })
        result = k.route_genre(card)
        self.assertEqual(result["genre"], "design_science")

    def test_empirical_quant_from_population_claim(self):
        card = load_example("claim_card.example.json")
        card["scope"]["generalization_claimed"] = "population_claim"
        result = k.route_genre(card)
        self.assertEqual(result["genre"], "empirical_quant")

    def test_conceptual_fallback(self):
        card = load_example("claim_card.example.json")
        card["standpoint"]["declared_basis"] = "reasoned argument only, no fieldwork of any kind"
        card["standpoint"]["method_basis"] = "conceptual synthesis of existing ideas"
        card["lens_translation"]["formal_applicability"] = "not_applicable_narrative"
        result = k.route_genre(card)
        self.assertEqual(result["genre"], "conceptual")

    def test_mixed_genre_when_multiple_branches_match(self):
        card = load_example("claim_card.example.json")
        card["lineage"]["derives_from"] = ["GLOSA-CC-20260101-0001"]
        # sequential routing (no opt-in) returns the FIRST match, position_reply (step4), since
        # step4 precedes step7 -- it never even reaches step7's case_study match.
        sequential = k.route_genre(card)
        self.assertEqual(sequential["genre"], "position_reply")
        # explicitly opting into the step-9 tie detector surfaces that step7 (case_study) ALSO
        # matched independently, and returns MIXED_GENRE for a human Approver to break the tie.
        mixed = k.route_genre(card, context={"check_mixed_genre": True})
        self.assertEqual(mixed["genre"], "MIXED_GENRE")

    def test_venue_track_and_companion_of_never_inputs(self):
        card = load_example("claim_card.example.json")
        card["venue_track"] = "thai_tci"
        card["companion_of"] = "some-artifact-id"
        result_a = k.route_genre(card)
        card["venue_track"] = "international"
        card["companion_of"] = None
        result_b = k.route_genre(card)
        self.assertEqual(result_a["genre"], result_b["genre"])


class IndependenceCeilingTest(unittest.TestCase):
    def test_i1_ceiling_is_dr_k0(self):
        result = k.independence_ceiling([{"independence_class": "I1"}])
        self.assertEqual(result["max_tier"], "Dr")
        self.assertEqual(result["max_k_state"], "K0")

    def test_i5_ceiling_is_th_coqc_k2(self):
        result = k.independence_ceiling([{"independence_class": "I1"}, {"independence_class": "I5"}])
        self.assertEqual(result["max_independence_class"], "I5")
        self.assertEqual(result["max_tier"], "Th_coqc")
        self.assertEqual(result["max_k_state"], "K2")

    def test_i3_ceiling_is_finite_diagnostic_k1(self):
        result = k.independence_ceiling([{"independence_class": "I3"}])
        self.assertEqual(result["max_tier"], "finite_diagnostic")
        self.assertEqual(result["max_k_state"], "K1")

    def test_empty_evidence_ceiling_is_conservative(self):
        result = k.independence_ceiling([])
        self.assertEqual(result["max_tier"], "Dr")
        self.assertEqual(result["max_k_state"], "K0")

    def test_many_weak_routes_do_not_beat_one_strong_route(self):
        """NC-31 ManyModels⇏Independence: count never substitutes for the highest level reached."""
        many_weak = [{"independence_class": "I1"}] * 10
        one_strong = [{"independence_class": "I4"}]
        self.assertEqual(
            k.independence_ceiling(many_weak)["max_tier"],
            k.independence_ceiling([{"independence_class": "I1"}])["max_tier"],
        )
        self.assertNotEqual(
            k.independence_ceiling(many_weak)["max_tier"],
            k.independence_ceiling(one_strong)["max_tier"],
        )


class DefeaterRouteTest(unittest.TestCase):
    def test_single_path_defeated_loses_distinction(self):
        dag = {"nodes": [{"id": "a"}, {"id": "b"}, {"id": "c"}], "edges": [{"from": "a", "to": "b"}, {"from": "b", "to": "c"}]}
        result = k.defeater_route(dag, "b")
        self.assertTrue(result["distinction_lost"])
        self.assertEqual(result["surviving_paths"], [])

    def test_alternate_path_survives(self):
        dag = {
            "nodes": [{"id": "a"}, {"id": "b"}, {"id": "c"}, {"id": "d"}],
            "edges": [{"from": "a", "to": "b"}, {"from": "b", "to": "d"}, {"from": "a", "to": "c"}, {"from": "c", "to": "d"}],
        }
        result = k.defeater_route(dag, "b")
        self.assertFalse(result["distinction_lost"])
        self.assertTrue(any("b" not in p for p in result["surviving_paths"]))

    def test_empty_dag_reports_no_loss(self):
        result = k.defeater_route({"nodes": [], "edges": []}, "x")
        self.assertFalse(result["distinction_lost"])
        self.assertEqual(result["all_paths_count"], 0)

    def test_worked_example_single_node_dag(self):
        card = load_example("claim_card.example.json")
        dag = card["provenance_dag"]
        result = k.defeater_route(dag, "obs-1")
        self.assertTrue(result["distinction_lost"])  # the only node, defeated -> nothing survives


class SilentLiftCheckTest(unittest.TestCase):
    def test_clean_card_passes(self):
        card = load_example("claim_card.example.json")
        res = k.silent_lift_check(card)
        self.assertTrue(res["ok"], res["errors"])

    def test_undisclosed_dependency_is_hard_fail(self):
        card = load_example("claim_card.example.json")
        card["silent_lift_check"]["actual_dependency_set"] = ["obs-1", "ai-inferred-node-X"]
        res = k.silent_lift_check(card)
        self.assertFalse(res["ok"])
        self.assertIn("ai-inferred-node-X", res["computed_flags"])

    def test_already_recorded_flags_are_hard_fail(self):
        card = load_example("claim_card.example.json")
        card["silent_lift_check"]["flags"] = ["some-flag"]
        res = k.silent_lift_check(card)
        self.assertFalse(res["ok"])


class MC01CheckTest(unittest.TestCase):
    def test_distinct_ids_pass(self):
        res = k.mc01_check("alice", "bob", "carol")
        self.assertTrue(res["ok"])

    def test_maker_equals_checker_fails(self):
        res = k.mc01_check("alice", "alice", "carol")
        self.assertFalse(res["ok"])

    def test_missing_id_fails(self):
        res = k.mc01_check("alice", None, "carol")
        self.assertFalse(res["ok"])


class Rule22IntakeTierTest(unittest.TestCase):
    """rule22 (INTAKE-TIER-UNTIERED, FOUNDATION_v0.6_PATCH.md §4, thin scope per DECISIONS.md
    2026-09-05 BBL-2026-09-05-122): WARNING-only, never blocks."""

    def setUp(self):
        self.manifest = load_example("litreview_manifest.example.json")

    def test_request_tier_without_reason_warns_never_blocks(self):
        manifest = copy.deepcopy(self.manifest)
        manifest["citations"][0]["intake_tier"] = "request_tier"
        manifest["citations"][0]["intake_tier_reason"] = None
        res = k.lit_gate(manifest)
        self.assertTrue(res["ok"], res["errors"])
        self.assertTrue(any("rule22w" in w for w in res["warnings"]), res["warnings"])

    def test_request_tier_with_reason_is_silent(self):
        manifest = copy.deepcopy(self.manifest)
        manifest["citations"][0]["intake_tier"] = "request_tier"
        manifest["citations"][0]["intake_tier_reason"] = "grey-literature policy brief, genre normally suppresses full AACODS pass"
        res = k.lit_gate(manifest)
        self.assertTrue(res["ok"], res["errors"])
        self.assertFalse(any("rule22w" in w for w in res["warnings"]), res["warnings"])

    def test_not_flagged_is_silent(self):
        manifest = copy.deepcopy(self.manifest)
        manifest["citations"][0]["intake_tier"] = "not_flagged"
        res = k.lit_gate(manifest)
        self.assertFalse(any("rule22w" in w for w in res["warnings"]), res["warnings"])


class Rule25DiscoveryStageTest(unittest.TestCase):
    """rule25 (DISCOVERY-STAGE-ABSENT, FOUNDATION_v0.6_PATCH.md §23, optional S14 stage per
    DECISIONS.md 2026-09-05 'foundation.lrs-discovery-loop-extension = optional S14 stage'):
    WARNING-only, never blocks, and only evaluated when search_log is supplied."""

    def setUp(self):
        self.manifest = load_example("litreview_manifest.example.json")
        self.search_log = load_example("search_log.example.json")

    def test_systematic_review_without_candidate_set_stage_warns(self):
        sl = copy.deepcopy(self.search_log)
        sl["search_mode"] = "SYSTEMATIC_REVIEW"
        sl.pop("candidate_set_stage", None)
        res = k.lit_gate(self.manifest, search_log=sl)
        self.assertTrue(res["ok"], res["errors"])
        self.assertTrue(any("rule25w" in w for w in res["warnings"]), res["warnings"])

    def test_systematic_review_with_candidate_set_stage_is_silent(self):
        sl = copy.deepcopy(self.search_log)
        sl["search_mode"] = "SYSTEMATIC_REVIEW"
        sl["candidate_set_stage"] = {"candidates_generated": 12, "candidates_collapsed": 4, "routing_note": "merged near-duplicates"}
        res = k.lit_gate(self.manifest, search_log=sl)
        self.assertFalse(any("rule25w" in w for w in res["warnings"]), res["warnings"])

    def test_non_systematic_review_mode_is_silent(self):
        sl = copy.deepcopy(self.search_log)
        self.assertNotEqual(sl["search_mode"], "SYSTEMATIC_REVIEW")
        res = k.lit_gate(self.manifest, search_log=sl)
        self.assertFalse(any("rule25w" in w for w in res["warnings"]), res["warnings"])

    def test_search_log_omitted_is_silent_not_a_fabricated_pass(self):
        res = k.lit_gate(self.manifest)
        self.assertTrue(res["ok"], res["errors"])
        self.assertFalse(any("rule25w" in w for w in res["warnings"]), res["warnings"])


class Rule24PCSTest(unittest.TestCase):
    """rule24/rule24w (PCS-JOINT-CONDITION, FOUNDATION_v0.6_PATCH.md §6, kernel.pcs-red-flag)
    narrow scope, DECISIONS.md 2026-09-05 BBL-2026-09-05-122: ERROR only when BOTH closure-timing
    AND absence-of-adaptation hold jointly; WARNING when only one holds; silent otherwise."""

    def setUp(self):
        self.card = load_example("claim_card.example.json")

    def test_clean_card_is_silent(self):
        closure, absence = k._pcs_signals(self.card)
        self.assertFalse(closure)
        self.assertFalse(absence)
        res = k.validate_claim_card(self.card)
        self.assertFalse(any("rule24" in e for e in res["errors"]))
        self.assertFalse(any("rule24w" in w for w in res["warnings"]))

    def test_fail_fixture_both_conjuncts_is_hard_error(self):
        card = load_fail("fail_rule24_pcs_joint_condition.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule24(PCS-JOINT-CONDITION)" in e for e in res["errors"]), res["errors"])

    def test_closure_timing_alone_is_warning_not_error(self):
        card = copy.deepcopy(self.card)
        card["hypothesis_world"]["text"] += " The category was locked before the evidence-gathering step was complete."
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertFalse(any("rule24(" in e for e in res["errors"]))
        self.assertTrue(any("rule24w" in w for w in res["warnings"]), res["warnings"])

    def test_absence_of_adaptation_alone_is_warning_not_error(self):
        card = copy.deepcopy(self.card)
        card["hypothesis_world"]["text"] += " This finding was never revisited despite a changed context."
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertFalse(any("rule24(" in e for e in res["errors"]))
        self.assertTrue(any("rule24w" in w for w in res["warnings"]), res["warnings"])

    def test_never_merged_with_clinical_premature_closure(self):
        """PCS is a distinct, narrowly-scoped joint condition -- the clinical term 'premature
        closure' alone (with neither closure-timing nor absence-of-adaptation phrasing) must not
        fire either rule24 or rule24w."""
        card = copy.deepcopy(self.card)
        card["hypothesis_world"]["text"] += " Clinicians should avoid premature closure in diagnosis."
        res = k.validate_claim_card(card)
        self.assertFalse(any("rule24" in e for e in res["errors"]))
        self.assertFalse(any("rule24w" in w for w in res["warnings"]))


class ScopeContextTest(unittest.TestCase):
    """D-SCOPE-CONTEXT (FOUNDATION_v0.6_PATCH.md §14, foundation.s5-scope-boundary-per-instance)
    -- per-instance clause + context check, WARNING-only, never blocks. DECISIONS.md 2026-09-05
    BBL-2026-09-05-122."""

    def setUp(self):
        self.card = load_example("claim_card.example.json")

    def test_non_health_legal_card_is_silent(self):
        self.assertIsNone(k._scope_context_warning(self.card))
        ids = {d["id"] for d in k.compute_disclaimers(self.card)}
        self.assertNotIn("D-SCOPE-CONTEXT", ids)

    def test_health_domain_without_clause_warns(self):
        card = copy.deepcopy(self.card)
        card["statement"]["text"] += " This is offered as clinical advice for symptom treatment."
        res = k.validate_claim_card(card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertTrue(any("D-SCOPE-CONTEXT" in w for w in res["warnings"]), res["warnings"])
        ids = {d["id"] for d in k.compute_disclaimers(card)}
        self.assertIn("D-SCOPE-CONTEXT", ids)

    def test_translation_text_scanned_by_both_routes(self):
        # review finding (v0.4.1): compute_disclaimers and _scope_context_warning must scan the
        # same field set, including statement.translation.text, so they never diverge.
        card = copy.deepcopy(self.card)
        card["statement"]["translation"] = {"text": "clinical advice about symptom treatment", "language": "en"}
        self.assertIsNotNone(k._scope_context_warning(card))
        ids = {d["id"] for d in k.compute_disclaimers(card)}
        self.assertIn("D-NOT-DIAGNOSTIC", ids)
        self.assertIn("D-SCOPE-CONTEXT", ids)

    def test_health_domain_with_per_instance_clause_is_silent(self):
        card = copy.deepcopy(self.card)
        card["statement"]["text"] += " This is offered as clinical advice for symptom treatment."
        card["scope"]["per_instance_scope_clause"] = {
            "time_criticality": "not delay-sensitive",
            "jurisdiction": "Thailand",
            "legal_category_available": True,
        }
        res = k.validate_claim_card(card)
        self.assertFalse(any("D-SCOPE-CONTEXT" in w for w in res["warnings"]), res["warnings"])
        ids = {d["id"] for d in k.compute_disclaimers(card)}
        self.assertNotIn("D-SCOPE-CONTEXT", ids)


class LitGateTest(unittest.TestCase):
    def test_valid_litreview_manifest_passes(self):
        manifest = load_example("litreview_manifest.example.json")
        res = k.lit_gate(manifest)
        self.assertTrue(res["ok"], res["errors"])
        self.assertEqual(res["verdict"], "PASS_WITH_LIMITS")

    def test_violations_found_blocks_pass(self):
        manifest = load_example("litreview_manifest.example.json")
        manifest["secondary_citation_ban_audit"]["violations_found"] = 2
        manifest["gate"]["overall"] = "PASS"
        res = k.lit_gate(manifest)
        self.assertFalse(res["ok"])

    def test_fail_without_blocked_reason_is_kernel_error(self):
        manifest = load_example("litreview_manifest.example.json")
        manifest["gate"]["overall"] = "FAIL"
        manifest["gate"]["blocked_reason"] = None
        res = k.lit_gate(manifest)
        self.assertFalse(res["ok"])

    def test_overall_may_not_be_looser_than_worst_subgate(self):
        manifest = load_example("litreview_manifest.example.json")
        manifest["gate"]["accuracy_gate"] = "FAIL"
        manifest["gate"]["diversity_gate"] = "PASS"
        manifest["gate"]["overall"] = "PASS"
        res = k.lit_gate(manifest)
        self.assertFalse(res["ok"])


class GateReleaseTest(unittest.TestCase):
    def setUp(self):
        self.manifest = load_example("release_manifest.example.json")
        self.card = load_example("claim_card.example.json")
        self.review = load_example("review_report.example.json")

    def test_worked_example_gate_release(self):
        # the worked example's review is I3, matching §6.4's minimum bar.
        result = k.gate_release(self.manifest, [self.card], [self.review])
        self.assertIn(result["verdict"], ("PASS", "PASS_WITH_LIMITS"))
        self.assertEqual(result["tier"], "finite_diagnostic")

    def test_missing_claim_card_is_hard_fail(self):
        result = k.gate_release(self.manifest, [], [self.review])
        self.assertEqual(result["verdict"], "FAIL")
        self.assertTrue(any("no matching claim_card" in r for r in result["reasons"]))

    def test_stub_card_cannot_be_released(self):
        stub = load_fail("fail_stub_public.json")
        stub["status"] = "Draft"
        stub["claim_id"] = self.manifest["artifact_refs"]["claim_ids"][0]
        result = k.gate_release(self.manifest, [stub], [self.review])
        self.assertEqual(result["verdict"], "FAIL")

    def test_no_i3_plus_review_or_evidence_blocks_approved_status(self):
        weak_card = copy.deepcopy(self.card)
        result = k.gate_release(self.manifest, [weak_card], [])  # example manifest status is Pending Review, not Approved-*
        # Pending Review manifest does not trigger the §6.4 mandatory-gate check (only Approved-* does)
        self.assertNotEqual(result["verdict"], "HUMAN_REVIEW")

        approved_manifest = copy.deepcopy(self.manifest)
        approved_manifest["status"] = "Approved-for-Test"
        result2 = k.gate_release(approved_manifest, [weak_card], [])
        self.assertEqual(result2["verdict"], "FAIL")
        self.assertTrue(any("§6.4" in r for r in result2["reasons"]))

    def test_unresolved_dissent_routes_to_human_review(self):
        card = copy.deepcopy(self.card)
        card["five_questions"]["tested"]["dissent_records"] = [
            {"by": "founder", "date": "2026-09-05", "content": "disputed reading", "resolved": False}
        ]
        result = k.gate_release(self.manifest, [card], [self.review])
        self.assertEqual(result["verdict"], "HUMAN_REVIEW")


class SelfTestTest(unittest.TestCase):
    def test_self_test_passes_clean(self):
        res = k.self_test()
        self.assertTrue(res["ok"], res["errors"])


class SchemaValidationBackendTest(unittest.TestCase):
    """Confirms jsonschema is actually being exercised in this environment (not silently falling
    back), so the rest of this suite's PASS results reflect the real schema, not the coarse
    fallback. If jsonschema genuinely is not installed here, this test documents that instead of
    failing silently."""

    def test_jsonschema_backend_status(self):
        card = load_example("claim_card.example.json")
        errors, used_fallback = k._schema_validate(card, "claim_card.schema.json")
        if not k._HAVE_JSONSCHEMA:
            self.assertTrue(used_fallback)
        else:
            self.assertFalse(used_fallback)
            self.assertEqual(errors, [])


class SchemaFailClosedTest(unittest.TestCase):
    """MUST-4 (reviews/ARCH_integrity.md F1/F3): validate_claim_card (and every other validate_*
    function) must FAIL CLOSED -- ok:False with a plain "jsonschema not available; schema
    validation not performed" error -- the moment schema validation silently falls back to the
    coarse presence-only check, unless the caller explicitly opts in via allow_no_jsonschema=True
    (which downgrades the result tier to Dr and adds a warning instead). Unavailability is
    simulated by monkeypatching `k._validator_for` to always return None -- the exact code path
    `_schema_validate` takes when jsonschema cannot be imported, without actually uninstalling the
    package."""

    def setUp(self):
        self._orig_validator_for = k._validator_for
        k._validator_for = lambda schema_filename: None

    def tearDown(self):
        k._validator_for = self._orig_validator_for

    def _f1_style_illegitimate_card(self):
        """reviews/ARCH_integrity.md F1's own reproduction: fail_k2_without_i5.json's base,
        mutated to tier:Th_coqc / k_state-supporting fields / status:Approved-for-Live with I5
        evidence and three distinct AI-vendor identities -- exactly the payload that returned
        ok:True, with jsonschema active, before MUST-4/MUST-7."""
        card = load_fail("fail_k2_without_i5.json")
        card["tier"] = "Th_coqc"
        card["status"] = "Approved-for-Live"
        card["provenance_dag"]["status"] = "run"
        card["silent_lift_check"]["status"] = "run"
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I5"
        card["independent_check"] = {
            "status": "PASSED", "maker_id": "claude-session-A", "checker_id": "gemini-session-B",
            "approver_id": "codex-session-C", "independence_class": "I5", "mc_level": "L5",
            "date": "2026-09-06", "expires_at": None,
        }
        return card

    def test_fails_closed_by_default_when_jsonschema_unavailable(self):
        card = self._f1_style_illegitimate_card()
        errors, used_fallback = k._schema_validate(card, "claim_card.schema.json")
        self.assertTrue(used_fallback)  # confirms the monkeypatch actually forced fallback mode
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(
            any("jsonschema not available; schema validation not performed" in e for e in res["errors"]),
            res["errors"],
        )

    def test_all_validate_functions_fail_closed_by_default_and_downgrade_tier_on_opt_in(self):
        pairs = [
            ("claim_card.example.json", k.validate_claim_card),
            ("review_report.example.json", k.validate_review_report),
            ("citation_card.example.json", k.validate_citation_card),
            ("release_manifest.example.json", k.validate_release_manifest),
            ("blackbox_note.example.json", k.validate_blackbox_note),
        ]
        for filename, fn in pairs:
            instance = load_example(filename)

            closed = fn(instance)
            self.assertFalse(closed["ok"], (filename, closed))
            self.assertTrue(
                any("jsonschema not available; schema validation not performed" in e for e in closed["errors"]),
                (filename, closed["errors"]),
            )

            opened = fn(instance, allow_no_jsonschema=True)
            self.assertTrue(opened["ok"], (filename, opened["errors"]))
            self.assertEqual(opened["tier"], "Dr", filename)
            self.assertTrue(
                any("allow_no_jsonschema=True" in w for w in opened["warnings"]), (filename, opened["warnings"])
            )

    def test_used_fallback_false_when_jsonschema_actually_available(self):
        k._validator_for = self._orig_validator_for  # restore for this one assertion only
        card = load_example("claim_card.example.json")
        errors, used_fallback = k._schema_validate(card, "claim_card.schema.json")
        if k._HAVE_JSONSCHEMA:
            self.assertFalse(used_fallback)
            res = k.validate_claim_card(card)
            self.assertEqual(res["tier"], "finite_diagnostic")


class LensSignatureCitationTest(unittest.TestCase):
    """MUST-6: kernel gate rule 12 (D-LENS-UNSIGNED, §3.3 rule 12) and the D-LENS-UNCITED
    lens-citation gate (§7.4). Positive/negative fixtures per the task instruction."""

    def setUp(self):
        self.card = load_example("claim_card.example.json")

    def _card_with_valid_signature(self):
        card = copy.deepcopy(self.card)
        card["lens_translation"]["lens_ref"] = "readout_universe"
        card["hypothesis_world"]["signature"] = (
            "hypothesis co-produced by founder+AI via lens readout_universe, 2026-09-04"
        )
        return card

    # -- D-LENS-UNSIGNED --

    def test_negative_no_lens_ref_is_untouched_by_rule12(self):
        self.assertIsNone((self.card.get("lens_translation") or {}).get("lens_ref"))
        res = k.validate_claim_card(self.card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertFalse(any("D-LENS-UNSIGNED" in e for e in res["errors"]))

    def test_lens_ref_without_signature_fails_rule12(self):
        card = copy.deepcopy(self.card)
        card["lens_translation"]["lens_ref"] = "readout_universe"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("D-LENS-UNSIGNED" in e for e in res["errors"]), res["errors"])

    def test_lens_ref_with_signature_not_naming_lens_fails_heuristic(self):
        card = copy.deepcopy(self.card)
        card["lens_translation"]["lens_ref"] = "readout_universe"
        card["hypothesis_world"]["signature"] = "co-produced by founder + AI, 2026-09-04"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(
            any("D-LENS-UNSIGNED" in e and "HEURISTIC" in e for e in res["errors"]), res["errors"]
        )

    def test_positive_lens_ref_with_correct_signature_passes_rule12(self):
        card = self._card_with_valid_signature()
        res = k.validate_claim_card(card)
        self.assertFalse(any("D-LENS-UNSIGNED" in e for e in res["errors"]), res["errors"])

    def test_compute_disclaimers_emits_d_lens_unsigned_when_rule12_fires(self):
        card = copy.deepcopy(self.card)
        card["lens_translation"]["lens_ref"] = "readout_universe"
        ids = {d["id"] for d in k.compute_disclaimers(card)}
        self.assertIn("D-LENS-UNSIGNED", ids)

    def test_compute_disclaimers_silent_on_d_lens_unsigned_when_no_lens_used(self):
        ids = {d["id"] for d in k.compute_disclaimers(self.card)}
        self.assertNotIn("D-LENS-UNSIGNED", ids)

    # -- D-LENS-UNCITED --

    def test_negative_lens_uncited_fails_when_citation_cards_empty(self):
        card = self._card_with_valid_signature()
        res = k.validate_claim_card(card, citation_cards=[])
        self.assertFalse(res["ok"])
        self.assertTrue(any("D-LENS-UNCITED" in e for e in res["errors"]), res["errors"])

    def test_lens_uncited_fails_when_citation_card_present_but_not_verified(self):
        card = self._card_with_valid_signature()
        citation_cards = [{
            "id": "cite-lens-001",
            "identifier": {"kind": "DOI", "value": "readout_universe"},
            "status": "PENDING",
        }]
        res = k.validate_claim_card(card, citation_cards=citation_cards)
        self.assertFalse(res["ok"])
        self.assertTrue(any("D-LENS-UNCITED" in e for e in res["errors"]), res["errors"])

    def test_positive_lens_uncited_passes_with_matching_verified_citation_card(self):
        card = self._card_with_valid_signature()
        citation_cards = [
            {
                "id": "cite-lens-001",
                "identifier": {"kind": "DOI", "value": "readout_universe"},
                "status": "VERIFIED",
            },
            # rule28 (INFLATED-BEARING) resolution target for the card's own
            # evidence_relations[0].citation_ref -- included so this positive fixture is not
            # incidentally flagged as an unresolvable-reference bearing inflation.
            load_example("citation_card.example.json"),
        ]
        res = k.validate_claim_card(card, citation_cards=citation_cards)
        self.assertTrue(res["ok"], res["errors"])
        ids = {d["id"] for d in k.compute_disclaimers(card, citation_cards=citation_cards)}
        self.assertNotIn("D-LENS-UNCITED", ids)

    def test_lens_uncited_not_checked_when_citation_cards_omitted(self):
        card = self._card_with_valid_signature()
        res = k.validate_claim_card(card)  # citation_cards defaults to None
        self.assertTrue(res["ok"], res["errors"])  # honest silence, never a fabricated pass
        self.assertTrue(
            any("D-LENS-UNCITED not checked" in w for w in res["warnings"]), res["warnings"]
        )


class HumanApproverTest(unittest.TestCase):
    """MUST-7 (reviews/ARCH_integrity.md F1): MC-01 human-Approver-identity extension.
    Reproduces F1's own payload -- three distinct AI-vendor identities reaching
    tier:Th_coqc/k_state-supporting-K2-fields/status:Approved-for-Live with ok:True and zero
    disclaimer naming the missing human -- and confirms it is now rejected everywhere the task
    named: validate_claim_card, validate_review_report, validate_release_manifest, gate_release."""

    def _all_ai_chain_card(self):
        card = load_fail("fail_k2_without_i5.json")
        card["tier"] = "Th_coqc"
        card["status"] = "Approved-for-Live"
        card["provenance_dag"]["status"] = "run"
        card["silent_lift_check"]["status"] = "run"
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I5"
        card["independent_check"] = {
            "status": "PASSED", "maker_id": "claude-session-A", "checker_id": "gemini-session-B",
            "approver_id": "codex-session-C", "independence_class": "I5", "mc_level": "L5",
            "date": "2026-09-06", "expires_at": None,
            # deliberately no approver_kind -- the all-AI chain reviews/ARCH_integrity.md F1
            # reproduced live, which previously reached ok:True with zero warning.
        }
        return card

    def test_all_ai_chain_rejected_at_approved_for_live(self):
        card = self._all_ai_chain_card()
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("MC-01-HUMAN" in e and "human" in e for e in res["errors"]), res["errors"])

    def test_all_ai_chain_rejected_even_when_approver_kind_explicitly_ai(self):
        card = self._all_ai_chain_card()
        card["independent_check"]["approver_kind"] = "ai"
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("MC-01-HUMAN" in e for e in res["errors"]), res["errors"])

    def test_human_approver_kind_clears_the_gate(self):
        card = self._all_ai_chain_card()
        card["independent_check"]["approver_kind"] = "human"
        res = k.validate_claim_card(card)
        self.assertFalse(any("MC-01-HUMAN" in e for e in res["errors"]), res["errors"])

    def test_k2_with_a_passed_independent_check_requires_human_approver_kind(self):
        card = copy.deepcopy(load_example("claim_card.example.json"))
        card["k_state"] = "K2"
        card["provenance_dag"]["status"] = "run"
        card["silent_lift_check"]["status"] = "run"
        card["five_questions"]["tested"]["evidence_relations"][0]["independence_class"] = "I5"
        card["independent_check"] = {
            "status": "PASSED", "maker_id": "a", "checker_id": "b", "approver_id": "c",
            "independence_class": "I5", "mc_level": "L4", "date": "2026-09-04", "expires_at": None,
        }
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("MC-01-HUMAN" in e for e in res["errors"]), res["errors"])

        card["independent_check"]["approver_kind"] = "human"
        res2 = k.validate_claim_card(card)
        self.assertFalse(any("MC-01-HUMAN" in e for e in res2["errors"]), res2["errors"])

    def test_k2_without_a_passed_independent_check_does_not_trigger_the_human_gate(self):
        # An isolated k_state=K2 mutation with no completed independent check (mirrors
        # KernelRuleIsolationTest.test_rule4_k2_k3_require_i5's own base state) must not itself
        # demand approver_kind -- there is no Approver identity to validate yet; rule 4's own
        # I5-evidence requirement is a separate, prior gate this test does not touch.
        card = copy.deepcopy(load_example("claim_card.example.json"))
        card["k_state"] = "K2"
        self.assertEqual(card["independent_check"]["status"], "NONE")
        res = k.validate_claim_card(card)
        self.assertFalse(any("MC-01-HUMAN" in e for e in res["errors"]), res["errors"])

    def test_review_report_i5_requires_human_approver_kind(self):
        report = load_example("review_report.example.json")
        report["independence_class"] = "I5"
        res = k.validate_review_report(report)
        self.assertFalse(res["ok"])
        self.assertTrue(any("MC-01-HUMAN" in e for e in res["errors"]), res["errors"])

        report["approver_kind"] = "human"
        res2 = k.validate_review_report(report)
        self.assertFalse(any("MC-01-HUMAN" in e for e in res2["errors"]), res2["errors"])

    def test_release_manifest_approved_for_live_requires_human_approver_kind(self):
        manifest = load_example("release_manifest.example.json")
        manifest["status"] = "Approved-for-Live"
        del manifest["independent_check_summary"]["approver_kind"]
        res = k.validate_release_manifest(manifest)
        self.assertFalse(res["ok"])
        self.assertTrue(any("MC-01-HUMAN" in e for e in res["errors"]), res["errors"])

        manifest["independent_check_summary"]["approver_kind"] = "human"
        res2 = k.validate_release_manifest(manifest)
        self.assertFalse(any("MC-01-HUMAN" in e for e in res2["errors"]), res2["errors"])

    def test_gate_release_rejects_all_ai_chain(self):
        manifest = load_example("release_manifest.example.json")
        manifest["status"] = "Approved-for-Live"
        del manifest["independent_check_summary"]["approver_kind"]
        card = self._all_ai_chain_card()
        card["claim_id"] = manifest["artifact_refs"]["claim_ids"][0]
        review = load_example("review_report.example.json")
        review["claim_ref"] = card["claim_id"]
        result = k.gate_release(manifest, [card], [review])
        self.assertEqual(result["verdict"], "FAIL")
        self.assertTrue(any("MC-01-HUMAN" in r for r in result["reasons"]), result["reasons"])


class XenonLedgerTest(unittest.TestCase):
    """MUST-12: xenon_ledger_check counts unresolved SCRAMMED citation_cards among a supplied
    batch and hard-fails above a threshold; gate_release wires it in when citation_cards is
    supplied, and honestly discloses the gap when it is not."""

    def _scrammed(self, n, resolved=0):
        cards = []
        for i in range(n):
            cards.append({
                "id": f"cite-scram-{i:03d}",
                "status": "SCRAMMED",
                "superseded_by": "cite-replacement-001" if i < resolved else None,
            })
        return cards

    def test_under_threshold_passes(self):
        res = k.xenon_ledger_check(self._scrammed(2))
        self.assertTrue(res["ok"], res["errors"])
        self.assertEqual(res["unresolved_scrammed_count"], 2)

    def test_over_threshold_fails(self):
        res = k.xenon_ledger_check(self._scrammed(4))
        self.assertFalse(res["ok"])
        self.assertTrue(any("xenon_ledger_check" in e for e in res["errors"]), res["errors"])

    def test_resolved_scrammed_not_counted(self):
        cards = self._scrammed(5, resolved=5)  # every SCRAMMED card has superseded_by set
        res = k.xenon_ledger_check(cards)
        self.assertTrue(res["ok"], res["errors"])
        self.assertEqual(res["unresolved_scrammed_count"], 0)

    def test_custom_threshold(self):
        res = k.xenon_ledger_check(self._scrammed(2), threshold=1)
        self.assertFalse(res["ok"])

    def test_gate_release_wires_xenon_ledger_check(self):
        manifest = load_example("release_manifest.example.json")
        card = load_example("claim_card.example.json")
        review = load_example("review_report.example.json")
        result = k.gate_release(manifest, [card], [review], citation_cards=self._scrammed(5))
        self.assertEqual(result["verdict"], "FAIL")
        self.assertTrue(any("xenon_ledger" in r for r in result["reasons"]), result["reasons"])

    def test_gate_release_without_citation_cards_notes_the_gap(self):
        manifest = load_example("release_manifest.example.json")
        card = load_example("claim_card.example.json")
        review = load_example("review_report.example.json")
        result = k.gate_release(manifest, [card], [review])
        self.assertTrue(
            any("Xenon Ledger threshold check" in r and "NOT run" in r for r in result["reasons"]),
            result["reasons"],
        )

    def test_gate_release_passes_with_citation_cards_under_threshold(self):
        manifest = load_example("release_manifest.example.json")
        card = load_example("claim_card.example.json")
        review = load_example("review_report.example.json")
        # rule28 (INFLATED-BEARING) needs card's own evidence_relations[0].citation_ref
        # ("cite-cat-obs-001") to resolve -- included alongside the scrammed batch so this
        # under-threshold fixture is not incidentally flagged as an unresolvable reference.
        citation_cards = self._scrammed(1) + [load_example("citation_card.example.json")]
        result = k.gate_release(manifest, [card], [review], citation_cards=citation_cards)
        self.assertIn(result["verdict"], ("PASS", "PASS_WITH_LIMITS"))


class KernelRuleV06PatchTest(unittest.TestCase):
    """design/FOUNDATION_v0.6_PATCH.md rules 18-28 (skipping 22/24/25, pending-founder). One
    test per implemented rule, mirroring KernelRuleIsolationTest's own convention (minimal
    mutation of the valid claim_card/citation_card example) plus a fail-fixture check for each
    rule that has a dedicated schema/examples/fail/*.json file."""

    def setUp(self):
        self.card = load_example("claim_card.example.json")
        self.citation = load_example("citation_card.example.json")

    # -- rule18: injected-infinity/zero taxonomy (standalone kernel text-scan) --

    def test_rule18_taxonomy_untyped(self):
        card = load_fail("fail_rule18_injected_infinity.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule18(TAXONOMY-UNTYPED)" in e and "I4" in e for e in res["errors"]), res["errors"])

    def test_rule18_clean_prose_untouched(self):
        res = k.validate_claim_card(self.card)
        self.assertFalse(any("rule18" in e for e in res["errors"]), res["errors"])

    def test_rule18_every_taxonomy_code_named(self):
        """DAG acceptance test refinement: one synthetic card per I/Z code, each raises the
        correctly-named type -- not merely caught untyped."""
        probes = {
            "I1": "the value is fixed by a Dedekind cut of the rationals",
            "I2": "as the interval width -> 0 the limit is treated as reached",
            "I3": "as the sample count -> infinity the estimate approaches infinity",
            "I4": "the count is actually infinite",
            "Z1": "r = 0 is the reached point",
            "Z2": "h = 0 is the reached continuum spacing",
            "Z3": "the system reaches absolute rest",
            "Z4": "this is the true void",
        }
        for code, text in probes.items():
            card = copy.deepcopy(self.card)
            card["hypothesis_world"]["text"] = text
            res = k.validate_claim_card(card)
            self.assertFalse(res["ok"], f"{code}: expected a hard fail for {text!r}")
            self.assertTrue(
                any(f"rule18(TAXONOMY-UNTYPED)" in e and f"{code} non-readout" in e for e in res["errors"]),
                f"{code}: expected a named-type rule18 error, got {res['errors']}",
            )

    # -- rule19: Fail-Able Gate Law (Type-P/Type-U) --

    def test_rule19_gate_type_unstated(self):
        card = load_fail("fail_rule19_gate_type_unstated.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule19" in e for e in res["errors"]), res["errors"])

    def test_rule19_type_p_with_failing_control_passes(self):
        card = copy.deepcopy(self.card)
        card["gate_construction_status"] = {
            "gate_id": "gate-cat-litterbox-001", "type": "Type-P", "failing_control_ref": "fixture-neg-001",
        }
        res = k.validate_claim_card(card, citation_cards=[self.citation])
        self.assertFalse(any("rule19" in e for e in res["errors"]), res["errors"])

    def test_rule19_type_u_without_failing_control_passes(self):
        card = copy.deepcopy(self.card)
        card["gate_construction_status"] = {"gate_id": "gate-cat-litterbox-001", "type": "Type-U", "failing_control_ref": None}
        res = k.validate_claim_card(card, citation_cards=[self.citation])
        self.assertFalse(any("rule19" in e for e in res["errors"]), res["errors"])

    # -- rule20: forbidden-word-list rejection (schema-enforced) --

    def test_rule20_priority_word_rejected(self):
        card = load_fail("fail_rule20_priority_word_rejected.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    def test_rule20_thai_priority_word_rejected(self):
        card = copy.deepcopy(self.card)
        card["comparison"] = {"target": None, "relation": "same", "basis": "เป็นครั้งแรกที่พบรูปแบบนี้"}
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    def test_rule20_same_different_cited_not_compared_accepted(self):
        for relation in ("same", "different", "cited", "not_compared"):
            card = copy.deepcopy(self.card)
            card["comparison"] = {"target": "GLOSA-CC-00000000-0000", "relation": relation, "basis": "compared against a prior single-household case, method differs"}
            res = k.validate_claim_card(card, citation_cards=[self.citation])
            self.assertTrue(res["ok"], (relation, res["errors"]))

    def test_rule20_empty_basis_once_comparison_present_is_error(self):
        card = copy.deepcopy(self.card)
        card["comparison"] = {"target": None, "relation": "not_compared", "basis": ""}
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    # -- rule21: genre/register layer-mismatch (warning-only diagnostic) --

    def test_rule21_layer_mismatch_warns_not_fails(self):
        card = copy.deepcopy(self.card)
        card["standpoint"]["declared_basis"] = "fatwa issued by the local jurisprudential committee"
        card["five_questions"]["tested"]["evidence_relations"][0]["notes"] = "confirmed by telescope observation and ephemeris calculation"
        res = k.validate_claim_card(card, citation_cards=[self.citation])
        self.assertTrue(res["ok"], res["errors"])
        self.assertTrue(any("rule21" in w for w in res["warnings"]), res["warnings"])

    def test_rule21_matching_layers_silent(self):
        card = copy.deepcopy(self.card)
        card["standpoint"]["declared_basis"] = "fatwa issued by the local jurisprudential committee"
        card["five_questions"]["tested"]["evidence_relations"][0]["notes"] = "fiqh ruling on this matter"
        res = k.validate_claim_card(card, citation_cards=[self.citation])
        self.assertFalse(any("rule21" in w for w in res["warnings"]), res["warnings"])

    # -- rule23: verdict_class six-value enum (schema-enforced) --

    def test_rule23_verdict_class_unlisted(self):
        card = load_fail("fail_rule23_verdict_class_unlisted.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])

    def test_rule23_verdict_class_forced_accepted(self):
        card = copy.deepcopy(self.card)
        card["verdict_class"] = "FORCED"
        res = k.validate_claim_card(card, citation_cards=[self.citation])
        self.assertTrue(res["ok"], res["errors"])

    # -- rule26: composite-quote detector (citation_card, kernel-only) --

    def test_rule26_composite_quote(self):
        citation = load_fail("fail_rule26_composite_quote.json")
        res = k.validate_citation_card(citation)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule26" in e for e in res["errors"]), res["errors"])

    def test_rule26_splice_double_hyphen_variant(self):
        citation = copy.deepcopy(self.citation)
        citation["exact_passage"] = "first half of the quote -- second half glued on"
        res = k.validate_citation_card(citation)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule26" in e for e in res["errors"]), res["errors"])

    def test_rule26_clean_passage_passes(self):
        res = k.validate_citation_card(self.citation)
        self.assertTrue(res["ok"], res["errors"])

    # -- rule27: hidden-AI-fill detector --

    def test_rule27_hidden_ai_fill(self):
        card = load_fail("fail_rule27_hidden_ai_fill.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule27" in e for e in res["errors"]), res["errors"])

    def test_rule27_disclosed_ai_involvement_passes(self):
        card = copy.deepcopy(self.card)
        card["five_questions"]["seen"]["ai_assisted_fields"] = ["access_model"]
        # ai_filled.retained_record_route already discloses AI drafting in the valid example --
        # not every value is a placeholder, so rule27 does not fire.
        res = k.validate_claim_card(card, citation_cards=[self.citation])
        self.assertFalse(any("rule27" in e for e in res["errors"]), res["errors"])

    def test_rule27_empty_ai_assisted_fields_untouched(self):
        res = k.validate_claim_card(self.card, citation_cards=[self.citation])
        self.assertFalse(any("rule27" in e for e in res["errors"]), res["errors"])

    # -- rule28: inflated-bearing detector --

    def test_rule28_inflated_bearing(self):
        card = load_fail("fail_rule28_inflated_bearing.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule28" in e for e in res["errors"]), res["errors"])

    def test_rule28_unresolvable_citation_ref_when_citation_cards_supplied(self):
        card = copy.deepcopy(self.card)
        res = k.validate_claim_card(card, citation_cards=[])  # cite-cat-obs-001 will not resolve
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule28" in e and "does not resolve" in e for e in res["errors"]), res["errors"])

    def test_rule28_context_only_citation_scope(self):
        card = copy.deepcopy(self.card)
        citation = copy.deepcopy(self.citation)
        citation["scope"] = "CONTEXT_ONLY_NOT_EVIDENCE"
        res = k.validate_claim_card(card, citation_cards=[citation])
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule28" in e and "CONTEXT_ONLY_NOT_EVIDENCE" in e for e in res["errors"]), res["errors"])

    def test_rule28_strength_context_is_honestly_scoped_and_passes(self):
        card = copy.deepcopy(self.card)
        card["five_questions"]["tested"]["evidence_relations"][0]["strength"] = "context"
        res = k.validate_claim_card(card, citation_cards=[])
        self.assertFalse(any("rule28" in e for e in res["errors"]), res["errors"])

    def test_rule28_resolved_direct_evidence_passes(self):
        res = k.validate_claim_card(self.card, citation_cards=[self.citation])
        self.assertTrue(res["ok"], res["errors"])


class SessionArchV04Test(unittest.TestCase):
    """design/SESSION_ARCH_v0.4_SPEC.md build_now nodes: kernel rule29 (strength-of-claim is not
    a defeater), rule30 (defeater_class-appropriate falsifier phrasing), NC-77 (retained_direction
    validate_hypothesis_selection), D-NO-PRECOMMIT-ROUTE (validate_problem_card), the unnumbered
    session-boundary cross-note check, and chi_recip_diagnostic."""

    def setUp(self):
        self.card = load_example("claim_card.example.json")
        self.selection = load_example("hypothesis_selection.example.json")
        self.problem_card = load_example("problem_card.example.json")
        self.blackbox_note = load_example("blackbox_note.example.json")

    # -- rule29: strength-of-claim is not a defeater --

    def test_rule29_strength_of_claim_defeater(self):
        card = load_fail("fail_rule29_strength_of_claim_defeater.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule29" in e for e in res["errors"]), res["errors"])

    def test_rule29_real_contrary_evidence_falsifier_passes(self):
        card = copy.deepcopy(self.card)
        card["five_questions"]["tested"]["falsifier"] = (
            "Defeated by a documented case where retained_direction is negative across 3 "
            "consecutive turns."
        )
        res = k.validate_claim_card(card, citation_cards=[load_example("citation_card.example.json")])
        self.assertFalse(any("rule29" in e for e in res["errors"]), res["errors"])

    def test_rule29_clean_example_untouched(self):
        res = k.validate_claim_card(self.card, citation_cards=[load_example("citation_card.example.json")])
        self.assertFalse(any("rule29" in e for e in res["errors"]), res["errors"])

    # -- rule30: defeater_class-appropriate falsifier phrasing --

    def test_rule30_defeater_class_mismatch(self):
        card = load_fail("fail_rule30_defeater_class_mismatch.json")
        res = k.validate_claim_card(card)
        self.assertFalse(res["ok"])
        self.assertTrue(any("rule30" in e for e in res["errors"]), res["errors"])

    def test_rule30_correct_pairing_passes(self):
        card = copy.deepcopy(self.card)
        card["five_questions"]["tested"]["defeater_class"] = "EMPIRICAL"
        card["five_questions"]["tested"]["falsifier"] = (
            "Defeated by a documented failed replication in an independent sample."
        )
        res = k.validate_claim_card(card, citation_cards=[load_example("citation_card.example.json")])
        self.assertFalse(any("rule30" in e for e in res["errors"]), res["errors"])

    def test_rule30_phenomenological_paired_with_absence_style_passes(self):
        card = copy.deepcopy(self.card)
        card["five_questions"]["tested"]["defeater_class"] = "PHENOMENOLOGICAL"
        card["five_questions"]["tested"]["falsifier"] = (
            "The phenomenon would be absent within the declared scope, systematically "
            "misdescribed, or explanatorily irrelevant."
        )
        res = k.validate_claim_card(card, citation_cards=[load_example("citation_card.example.json")])
        self.assertFalse(any("rule30" in e for e in res["errors"]), res["errors"])

    def test_rule30_absent_defeater_class_untouched(self):
        res = k.validate_claim_card(self.card, citation_cards=[load_example("citation_card.example.json")])
        self.assertFalse(any("rule30" in e for e in res["errors"]), res["errors"])

    # -- NC-77 / validate_hypothesis_selection --

    def test_nc77_retained_direction_unforced_rejected(self):
        selection = load_fail("fail_nc77_retained_direction_unforced.json")
        res = k.validate_hypothesis_selection(selection)
        self.assertFalse(res["ok"])
        self.assertTrue(any("NC-77" in e for e in res["errors"]), res["errors"])

    def test_nc77_default_unknown_passes(self):
        res = k.validate_hypothesis_selection(self.selection)
        self.assertTrue(res["ok"], res["errors"])

    def test_nc77_single_session_direction_not_forced(self):
        # Spans <2 sessions (no session_id anywhere) -- NC-77 does not fire even with a declared
        # direction, per the acceptance test's own "scoped to single-session rows" clause.
        selection = copy.deepcopy(self.selection)
        selection["retained_direction"] = "expansion"
        res = k.validate_hypothesis_selection(selection)
        self.assertTrue(res["ok"], res["errors"])

    def test_nc77_resolved_evidence_relation_stands(self):
        selection = copy.deepcopy(self.selection)
        selection["session_id"] = "sess-001"
        selection["chooser_reaffirmations"] = [
            {"session_id": "sess-002", "reaffirmed_by": "founder", "reaffirmed_at": "2026-09-06"}
        ]
        selection["retained_direction"] = "expansion"
        selection["direction_evidence_relation"] = {
            "evidence_id": "ev-checker-001",
            "bearing": "SUPPORTS",
            "independence_class": "I3",
            "citation_ref": "cite-checker-001",
        }
        res = k.validate_hypothesis_selection(selection)
        self.assertTrue(res["ok"], res["errors"])

    # -- D-NO-PRECOMMIT-ROUTE (validate_problem_card) --

    def test_no_precommit_route_flags_not_blocks(self):
        # problem_card.example.json reaches READY_FOR_S2 with no precommitted_resistance_route --
        # a flag, not a rejection.
        res = k.validate_problem_card(self.problem_card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertTrue(any("D-NO-PRECOMMIT-ROUTE" in w for w in res["warnings"]), res["warnings"])

    def test_precommit_route_named_clears_flag(self):
        card = copy.deepcopy(self.problem_card)
        card["intake"]["precommitted_resistance_route"] = "critic: a second household could replicate"
        res = k.validate_problem_card(card)
        self.assertTrue(res["ok"], res["errors"])
        self.assertFalse(any("D-NO-PRECOMMIT-ROUTE" in w for w in res["warnings"]), res["warnings"])

    def test_not_ready_for_s2_no_flag(self):
        card = copy.deepcopy(self.problem_card)
        card["readiness"]["verdict"] = "NOT_READY"
        res = k.validate_problem_card(card)
        self.assertFalse(any("D-NO-PRECOMMIT-ROUTE" in w for w in res["warnings"]), res["warnings"])

    # -- session-boundary reset (unnumbered, pending founder ratification of §2.2) --

    def test_session_boundary_not_reset_fixture_rejected_by_schema(self):
        note = load_fail("fail_session_boundary_not_reset.json")
        res = k.validate_blackbox_note(note)
        self.assertFalse(res["ok"])

    def test_session_boundary_shared_session_missing_reset_flagged(self):
        note_a = copy.deepcopy(self.blackbox_note)
        note_a["session_id"] = "sess-shared-001"
        note_a["session_boundary"] = {"opened_at": "t0", "closed_at": "t1", "ai_state_at_boundary": "reset"}
        note_b = copy.deepcopy(self.blackbox_note)
        note_b["id"] = "BB-2026-09-05-01"
        note_b["session_id"] = "sess-shared-001"
        note_b["session_boundary"] = {"opened_at": "t1", "closed_at": None}  # missing ai_state_at_boundary
        res = k.check_session_boundary_reset([note_a, note_b])
        self.assertFalse(res["ok"])
        self.assertTrue(any("session_boundary" in e for e in res["errors"]), res["errors"])

    def test_session_boundary_different_session_ids_not_flagged(self):
        note_a = copy.deepcopy(self.blackbox_note)
        note_a["session_id"] = "sess-001"
        note_a["session_boundary"] = {"ai_state_at_boundary": "reset"}
        note_b = copy.deepcopy(self.blackbox_note)
        note_b["id"] = "BB-2026-09-05-01"
        note_b["session_id"] = "sess-002"
        note_b["session_boundary"] = {}  # no ai_state_at_boundary, but different session -- not shared
        res = k.check_session_boundary_reset([note_a, note_b])
        self.assertTrue(res["ok"], res["errors"])

    # -- chi_recip_diagnostic (Open diagnostic over kg_edge; never a verdict) --

    def test_chi_recip_not_computable_without_session_id(self):
        edges = [
            {"id": "e1", "from": "n1", "to": "n2", "relation": "supports"},
            {"id": "e2", "from": "n2", "to": "n1", "relation": "supports"},
        ]
        result = k.chi_recip_diagnostic(edges, horizon=10)
        self.assertIn(None, result)
        self.assertTrue(result[None]["not_computable"])
        self.assertNotIn("chi_recip", result[None])

    def test_chi_recip_counts_reciprocal_pairs_and_is_reproducible(self):
        edges = [
            {"id": "e1", "from": "n1", "to": "n2", "relation": "supports", "session_id": "s1"},
            {"id": "e2", "from": "n2", "to": "n1", "relation": "supports", "session_id": "s1"},
            {"id": "e3", "from": "n3", "to": "n4", "relation": "derives_from", "session_id": "s1"},
        ]
        r1 = k.chi_recip_diagnostic(edges, horizon=10)
        r2 = k.chi_recip_diagnostic(edges, horizon=10)
        self.assertEqual(r1["s1"]["chi_recip"], 1)
        self.assertEqual(r1["s1"]["tier"], "Open")
        self.assertEqual(r1, r2)  # reproducible across repeated calls, same horizon

    def test_chi_recip_two_horizon_settings_both_computable(self):
        edges = [
            {"id": "e1", "from": "n1", "to": "n2", "relation": "supports", "session_id": "s1"},
            {"id": "e2", "from": "n2", "to": "n1", "relation": "supports", "session_id": "s1"},
        ]
        small = k.chi_recip_diagnostic(edges, horizon=1)  # only e1 in horizon -- no reciprocal pair yet
        full = k.chi_recip_diagnostic(edges, horizon=2)
        self.assertEqual(small["s1"]["chi_recip"], 0)
        self.assertEqual(full["s1"]["chi_recip"], 1)

    def test_chi_recip_rejects_non_positive_horizon(self):
        with self.assertRaises(ValueError):
            k.chi_recip_diagnostic([], horizon=0)

    def test_chi_recip_disclaimer_present_never_a_verdict_field(self):
        edges = [{"id": "e1", "from": "n1", "to": "n2", "relation": "supports", "session_id": "s1"}]
        result = k.chi_recip_diagnostic(edges, horizon=5)
        self.assertIn("disclaimer", result["s1"])
        self.assertNotIn("verdict", result["s1"])


if __name__ == "__main__":
    unittest.main()
