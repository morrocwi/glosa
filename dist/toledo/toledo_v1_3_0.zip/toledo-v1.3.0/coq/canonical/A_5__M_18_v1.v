(* A.5/M.18.v1 — CAN-241 — untagged — parents: A.5/M.01.v1 — occurrences 1 *)

From Coq Require Import QArith.
From Coq Require Import Lia.
From Coq Require Import List.
Import ListNotations.
Set Implicit Arguments.
From MRC Require Import MRC_Prelude.

(* CAN-241 — root: constitutional-noncollapse (CAN-008) — domain: method —
   tier: Th_coqc — occurrences: 1 *)
Theorem CAN241_intellectual_affinity_not_truth :
  CAN2xx_IntellectualAffinity <> CAN2xx_Truth.
Proof. discriminate. Qed.

